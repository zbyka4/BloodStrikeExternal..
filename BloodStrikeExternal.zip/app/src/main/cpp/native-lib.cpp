#include <jni.h>
#include <string>

extern "C" JNIEXPORT jstring JNICALL
Java_com_cart3r_jailbreak_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {
    std::string hello = "Native library loaded";
    return env->NewStringUTF(hello.c_str());
}
