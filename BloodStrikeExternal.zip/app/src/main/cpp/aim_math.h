#ifndef AIM_MATH_H
#define AIM_MATH_H

#include <cmath>
#include <algorithm>

struct Vector2 { float x; float y; };
struct Vector3 { float x; float y; float z; };

class AimMath {
public:
    static Vector2 CalculateAngle(const Vector3& localPosition, const Vector3& targetPosition) {
        Vector2 angles;
        float deltaX = targetPosition.x - localPosition.x;
        float deltaY = targetPosition.y - localPosition.y;
        float deltaZ = targetPosition.z - localPosition.z;
        float hyp = std::sqrt(deltaX * deltaX + deltaZ * deltaZ);
        angles.x = std::atan2(deltaY, hyp) * (180.0f / 3.14159265358979323846f);
        angles.y = std::atan2(deltaX, deltaZ) * (180.0f / 3.14159265358979323846f);
        return angles;
    }

    static Vector2 SmoothMovement(const Vector2& currentAngle, const Vector2& targetAngle, float smoothFactor) {
        Vector2 smoothed;
        float factor = std::clamp(smoothFactor, 1.0f, 50.0f);
        smoothed.x = currentAngle.x + (targetAngle.x - currentAngle.x) / factor;
        smoothed.y = currentAngle.y + (targetAngle.y - currentAngle.y) / factor;
        return smoothed;
    }
};
#endif
