package com.cart3r.jailbreak;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.widget.RemoteViews;
import androidx.core.app.NotificationCompat;

public class BackgroundNotificationService extends Service {
    private static final String CHANNEL_ID = "SystemSilentNotificationChannel";
    private static final int NOTIFICATION_ID = 1337;
    private static float smoothnessFactor = 28.0f; // Optimizado para Helio G35 / Redmi 9C
    private boolean aimbotActive = true;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, buildStealthNotification());
    }

    private void createNotificationChannel() {
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "Android System Runtime", NotificationManager.IMPORTANCE_LOW
        );
        channel.setShowBadge(false);
        channel.setSound(null, null);
        channel.enableVibration(false);
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) manager.createNotificationChannel(channel);
    }

    private Notification buildStealthNotification() {
        RemoteViews notificationLayout = new RemoteViews(getPackageName(), R.layout.notification_stealth_panel);
        String statusText = aimbotActive ? "ACTIVE | Smooth: " + smoothnessFactor : "STATUS: IDLE";
        notificationLayout.setTextViewText(R.id.txtStatus, statusText);

        Intent toggleIntent = new Intent(this, BackgroundNotificationService.class);
        toggleIntent.setAction("ACTION_TOGGLE");
        PendingIntent pToggle = PendingIntent.getService(this, 0, toggleIntent, PendingIntent.FLAG_IMMUTABLE);
        notificationLayout.setOnClickPendingIntent(R.id.btnToggle, pToggle);

        Intent incIntent = new Intent(this, BackgroundNotificationService.class);
        incIntent.setAction("ACTION_INC_SMOOTH");
        PendingIntent pInc = PendingIntent.getService(this, 1, incIntent, PendingIntent.FLAG_IMMUTABLE);
        notificationLayout.setOnClickPendingIntent(R.id.btnInc, pInc);

        Intent decIntent = new Intent(this, BackgroundNotificationService.class);
        decIntent.setAction("ACTION_DEC_SMOOTH");
        PendingIntent pDec = PendingIntent.getService(this, 2, decIntent, PendingIntent.FLAG_IMMUTABLE);
        notificationLayout.setOnClickPendingIntent(R.id.btnDec, pDec);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_manage)
                .setStyle(new NotificationCompat.DecoratedCustomViewStyle())
                .setCustomContentView(notificationLayout)
                .setPriority(NotificationCompat.PRIORITY_MIN)
                .setOngoing(true)
                .build();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            String action = intent.getAction();
            if ("ACTION_TOGGLE".equals(action)) {
                aimbotActive = !aimbotActive;
            } else if ("ACTION_INC_SMOOTH".equals(action)) {
                if (smoothnessFactor < 50.0f) smoothnessFactor += 5.0f;
            } else if ("ACTION_DEC_SMOOTH".equals(action)) {
                if (smoothnessFactor > 5.0f) smoothnessFactor -= 5.0f;
            }
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.notify(NOTIFICATION_ID, buildStealthNotification());
        }
        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY);
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
